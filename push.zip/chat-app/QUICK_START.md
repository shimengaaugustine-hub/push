# 🚀 Quick Start Guide - Deploy to Hostinger in 5 Minutes

## Option 1: One-Click Deployment (Easiest)

### Step 1: Prepare Package
1. Double-click `deploy.bat` in the chat-app folder
2. Wait for it to create the deployment package
3. Find the `deploy-package` folder

### Step 2: Create ZIP File
1. Right-click on `deploy-package` folder
2. Select "Send to" → "Compressed (zipped) folder"
3. Name it: `pushvault-deploy.zip`

### Step 3: Upload to Hostinger
1. Login to https://hpanel.hostinger.com
2. Go to "Files" → "File Manager"
3. Navigate to `public_html`
4. Click "Upload" → Select `pushvault-deploy.zip`
5. Right-click uploaded file → "Extract"
6. Move contents from `deploy-package` to `public_html`

### Step 4: Setup Node.js
1. In hPanel, go to "Advanced" → "Node.js"
2. Click "Create Application"
3. Settings:
   - **Application Root**: `/public_html`
   - **Application URL**: Your domain
   - **Application Startup File**: `server.js`
   - **Node.js Version**: 16.x or higher
4. Click "Create"
5. Click "Run NPM Install"
6. Click "Start Application"

### Step 5: Access Your App
Visit: `https://yourdomain.com`

**Done!** 🎉

---

## Option 2: FTP Upload (Recommended for Large Files)

### You'll Need:
- FTP client (FileZilla: https://filezilla-project.org)
- FTP credentials from Hostinger

### Steps:
1. **Get FTP Credentials**
   - hPanel → "Files" → "FTP Accounts"
   - Create account or use existing

2. **Connect FileZilla**
   - Host: `ftp.yourdomain.com`
   - Username: Your FTP username
   - Password: Your FTP password
   - Port: 21

3. **Upload Files**
   - Local site: Navigate to `chat-app` folder
   - Remote site: Navigate to `public_html`
   - Select all files → Right-click → "Upload"

4. **Follow Steps 4-5 from Option 1**

---

## Option 3: SSH/Terminal (Advanced)

### Prerequisites:
- SSH access enabled in Hostinger
- SSH client (PuTTY on Windows or Terminal on Mac/Linux)

### Steps:
1. **Connect via SSH**
   ```bash
   ssh username@yourdomain.com
   ```

2. **Navigate to web root**
   ```bash
   cd public_html
   ```

3. **Upload files** (choose one):
   
   **Via SCP (from your computer):**
   ```bash
   scp -r chat-app/* username@yourdomain.com:~/public_html/
   ```
   
   **Via Git:**
   ```bash
   git clone your-repo-url .
   ```

4. **Install dependencies**
   ```bash
   npm install
   ```

5. **Start with PM2** (if available)
   ```bash
   pm2 start ecosystem.config.js --env production
   pm2 save
   ```

6. **Or setup in hPanel Node.js** (follow Option 1, Step 4)

---

## ⚙️ Configuration

### Environment Variables (Optional)
1. In hPanel → Node.js → Your App → "Edit"
2. Add environment variables:
   ```
   PORT=3000
   NODE_ENV=production
   HOST=0.0.0.0
   ```

### Admin Key
- Default: `Admin1234`
- To change: Edit `server.js` line 75

### Login Codes
- CHAT001 - Timo
- CHAT002 - Augustine
- CHAT003 - Jordan
- CHAT004 - Bug
- CHAT005 - Brian

---

## 🔒 Security Setup (Important!)

### 1. Enable HTTPS
- hPanel → "Security" → "SSL"
- Install Let's Encrypt certificate (Free)
- Enable "Force HTTPS"

### 2. Update Admin Key
- Edit `server.js` → Change admin key
- Restart application

### 3. Set Folder Permissions
Via SSH or File Manager:
- `uploads` folder: 755
- All files: 644
- `server.js`: 644

---

## ✅ Post-Deployment Checklist

Test everything works:
- [ ] Can access `https://yourdomain.com`
- [ ] Login page loads
- [ ] Can login with CHAT001
- [ ] Can send text messages
- [ ] Can upload files (photos, documents)
- [ ] Can create polls
- [ ] Can share location
- [ ] Admin dashboard accessible (`/dashboard.html`)
- [ ] Mobile version works
- [ ] PWA install prompt appears

---

## 🆘 Troubleshooting

### App Won't Start
```bash
# SSH into server
cd public_html
npm install
# Check logs
cat logs/error.log
```

### Can't Upload Files
```bash
# Check uploads folder permissions
chmod 755 uploads
```

### WebSocket Issues
- Disable CDN temporarily
- Check if proxy_pass is configured correctly
- Verify port is open

### Need Help?
- Check `DEPLOYMENT.md` for detailed guide
- Contact Hostinger support (24/7 chat)
- Review `FEATURES.md` for feature documentation

---

## 📱 Access Points

After deployment, access your app at:

- **Main App**: `https://yourdomain.com`
- **Admin Dashboard**: `https://yourdomain.com/dashboard.html`
- **Admin Key**: `Admin1234`

---

## 🎯 Next Steps

1. **Test all features** ✓
2. **Change admin key** ✓
3. **Enable HTTPS** ✓
4. **Share with your team** ✓
5. **Customize branding** (optional)

---

## 💡 Pro Tips

- **Bookmark admin dashboard** for quick access
- **Enable automatic backups** in Hostinger
- **Monitor resource usage** in hPanel
- **Update regularly** for security patches
- **Consider database** for message persistence (future)

---

**Need detailed instructions?** See `DEPLOYMENT.md`

**Have questions?** Check the troubleshooting section above or contact support.

---

## 🎉 Congratulations!

Your PushVault Dev chat application is now live and ready to use!

**Built with ❤️ for real-time collaboration**
