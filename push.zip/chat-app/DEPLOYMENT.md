# PushVault Dev - Hostinger Deployment Guide

This guide will help you deploy your PushVault Dev chat application to Hostinger hosting.

## Prerequisites

- Hostinger account with Node.js hosting support
- SSH access to your server
- Domain name configured (optional)

## Deployment Steps

### Step 1: Prepare Your Files

Your application is now ready for deployment with the following structure:

```
chat-app/
├── public/              # Static files (HTML, CSS, JS)
├── uploads/             # User uploaded files
├── server.js            # Main server file
├── package.json         # Dependencies
├── .htaccess           # Apache configuration
├── .gitignore          # Git ignore rules
└── README.md           # Documentation
```

### Step 2: Upload to Hostinger

#### Option A: Using File Manager (Easy)

1. **Login to Hostinger hPanel**
   - Go to https://hpanel.hostinger.com
   - Login with your credentials

2. **Access File Manager**
   - Navigate to "Files" → "File Manager"
   - Go to `public_html` or your domain folder

3. **Upload Files**
   - Click "Upload" button
   - Select all files from `chat-app` folder
   - Wait for upload to complete

4. **Set Permissions**
   - Right-click `uploads` folder → "Permissions"
   - Set to 755 (drwxr-xr-x)

#### Option B: Using FTP (Recommended)

1. **Get FTP Credentials**
   - In hPanel, go to "Files" → "FTP Accounts"
   - Note down: hostname, username, password

2. **Connect via FTP Client (FileZilla)**
   - Host: ftp.yourdomain.com
   - Username: your_ftp_username
   - Password: your_ftp_password
   - Port: 21

3. **Upload Files**
   - Navigate to `public_html` or domain folder
   - Drag and drop all files from `chat-app`

#### Option C: Using SSH/Git (Advanced)

1. **Enable SSH Access**
   - In hPanel, go to "Advanced" → "SSH Access"
   - Enable SSH and note credentials

2. **Connect via SSH**
   ```bash
   ssh username@yourdomain.com
   ```

3. **Navigate to web root**
   ```bash
   cd public_html
   ```

4. **Clone from Git (if using Git)**
   ```bash
   git clone your-repository-url .
   ```

   **OR Upload via SCP**
   ```bash
   scp -r chat-app/* username@yourdomain.com:~/public_html/
   ```

### Step 3: Install Dependencies

1. **Connect to SSH Terminal**
   ```bash
   ssh username@yourdomain.com
   cd public_html
   ```

2. **Install Node.js Packages**
   ```bash
   npm install
   ```

### Step 4: Configure Node.js Application

1. **In Hostinger hPanel**
   - Go to "Advanced" → "Node.js"
   - Click "Create Application"

2. **Application Settings**
   - **Application Root**: `/public_html` or your domain path
   - **Application URL**: Your domain or subdomain
   - **Application Startup File**: `server.js`
   - **Node.js Version**: 14.x or higher
   - **Environment**: Production

3. **Environment Variables** (Optional)
   - Click "Edit" on your application
   - Add environment variables:
     ```
     PORT=3000
     NODE_ENV=production
     HOST=0.0.0.0
     ```

4. **Start Application**
   - Click "Run NPM Install" (if not done via SSH)
   - Click "Start Application"

### Step 5: Configure Domain (Optional)

If you want a custom domain:

1. **Domain Setup**
   - Go to "Domains" in hPanel
   - Add your domain or use Hostinger subdomain

2. **DNS Configuration**
   - Point A record to your server IP
   - Wait for DNS propagation (up to 24 hours)

### Step 6: Enable HTTPS (Recommended)

1. **SSL Certificate**
   - In hPanel, go to "Security" → "SSL"
   - Install free Let's Encrypt SSL certificate
   - Enable "Force HTTPS"

2. **Update .htaccess** (if using Apache)
   - Uncomment HTTPS redirect lines in `.htaccess`

## Port Configuration

### Default Ports:
- **Development**: 3000
- **Production**: Usually 3000 or 8080 (check Hostinger settings)

### If You Need to Change Port:

1. Edit `server.js`:
   ```javascript
   const PORT = process.env.PORT || 3000;
   ```

2. Or set environment variable in Node.js app settings

## Important Notes

### File Permissions
Ensure proper permissions for uploads folder:
```bash
chmod 755 uploads
chmod 644 uploads/*
```

### Security Checklist
- ✅ Change admin key from default
- ✅ Enable HTTPS/SSL
- ✅ Set proper file permissions
- ✅ Configure firewall rules (if available)
- ✅ Regular backups

### Performance Optimization
- ✅ Enable gzip compression (via .htaccess)
- ✅ Use CDN for static files (optional)
- ✅ Enable browser caching
- ✅ Monitor server resources

## Troubleshooting

### App Won't Start
1. Check Node.js version: `node --version` (should be 14+)
2. Verify all dependencies installed: `npm install`
3. Check application logs in Hostinger Node.js panel
4. Verify `server.js` path is correct

### Upload Issues
1. Check `uploads` folder exists and has write permissions
2. Verify folder path in `server.js`: `destination: 'uploads/'`
3. Check disk space quota in Hostinger

### Connection Issues
1. Verify application is running in Node.js panel
2. Check port number matches your configuration
3. Verify domain DNS settings
4. Check firewall settings (if applicable)

### Socket.io Connection Fails
1. Ensure WebSocket support is enabled
2. Check if reverse proxy is configured correctly
3. Try disabling any CDN/caching temporarily

## Monitoring & Maintenance

### Check Application Status
- Login to hPanel → "Advanced" → "Node.js"
- View application status and logs

### View Logs
- In Node.js application panel, click "Logs"
- Or via SSH: `tail -f logs/error.log`

### Restart Application
- In Node.js panel, click "Restart"
- Or via SSH: `pm2 restart server.js` (if using PM2)

### Update Application
1. Upload new files via FTP/File Manager
2. SSH into server: `cd public_html`
3. Run: `npm install` (if dependencies changed)
4. Restart application in Node.js panel

## Backup Strategy

### What to Backup
- All application files
- `uploads/` folder (user content)
- Database (if you add one later)

### Hostinger Backups
- Hostinger provides automatic weekly backups
- Manual backups available in "Files" → "Backups"

### Manual Backup via SSH
```bash
cd ~
tar -czf pushvault-backup-$(date +%Y%m%d).tar.gz public_html/
```

## Scaling & Performance

### As Your App Grows:

1. **Monitor Resources**
   - Check CPU/RAM usage in hPanel
   - Upgrade hosting plan if needed

2. **Database Integration** (Future)
   - Consider MongoDB or MySQL for message persistence
   - Store messages in database instead of memory

3. **Load Balancing** (Advanced)
   - Use Hostinger's load balancer
   - Multiple server instances for high traffic

## Support

### Hostinger Support
- Live chat: 24/7 support in hPanel
- Knowledge base: hostinger.com/tutorials
- Community forum: forum.hostinger.com

### Application Issues
- Check FEATURES.md for feature documentation
- Review README.md for application details
- Check server logs for errors

## Quick Reference

### Essential Commands
```bash
# Install dependencies
npm install

# Start application (dev)
npm start

# Start application (production)
npm run production

# Check Node version
node --version

# View running processes
pm2 list

# View logs
pm2 logs

# Restart app
pm2 restart server.js
```

### Admin Access
- Dashboard: `https://yourdomain.com/dashboard.html`
- Admin Key: `Admin1234`

### Login Codes
- CHAT001 - Timo
- CHAT002 - Augustine
- CHAT003 - Jordan
- CHAT004 - Bug
- CHAT005 - Brian

## Post-Deployment Checklist

- [ ] Application starts successfully
- [ ] Can access login page at your domain
- [ ] Can login with test credentials
- [ ] Can send and receive messages
- [ ] File uploads working
- [ ] Polls working
- [ ] Location sharing working
- [ ] Admin dashboard accessible
- [ ] SSL/HTTPS enabled
- [ ] Mobile version responsive
- [ ] PWA install prompt working

## Success!

Your PushVault Dev chat application is now live! 🎉

Access your app at: `https://yourdomain.com`

Need help? Check the troubleshooting section above or contact Hostinger support.
