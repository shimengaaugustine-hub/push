# PushVault Dev - Chat Room

A real-time chat application with file sharing capabilities, similar to WhatsApp/Telegram. Built with Node.js, Express, and Socket.io.

## Features

✨ **Real-time Messaging** - Instant message delivery to all connected users
📎 **File Sharing** - Share documents, images, and videos (up to 50MB)
❤️ **Reactions** - Like messages with reactions
👥 **User Presence** - See who's online in real-time
💬 **Typing Indicators** - Know when someone is typing
🎨 **Telegram-inspired UI** - Clean, modern interface with dark theme
📱 **Mobile Optimized** - Responsive design for all devices
🚀 **PWA Support** - Install as native app on any device
📊 **Interactive Polls** - Create and vote on polls in real-time
📍 **Location Sharing** - Share GPS coordinates with map links

## Login Codes

The application has 5 pre-configured access codes:

1. **CHAT001** - Timo
2. **CHAT002** - Augustine
3. **CHAT003** - Jordan
4. **CHAT004** - Bug
5. **CHAT005** - Brian

Each user logs in with their assigned code and will appear with their name in the chat.

## Installation

1. **Install Node.js** (if not already installed)
   Download from: https://nodejs.org/

2. **Install Dependencies**
   ```bash
   cd chat-app
   npm install
   ```

## Running the Application

1. **Start the Server**
   ```bash
   npm start
   ```

2. **Access the Chat**
   Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

3. **Login**
   - Enter one of the access codes (CHAT001-CHAT005)
   - Click "Join Chat"

## Usage

### Sending Messages
- Type your message in the input box
- Press Enter or click the send button

### Sharing Content
- Click the attachment button (📎) to open the attachment menu
- **Photo or Video**: Share images and videos
- **Document**: Share PDFs, Word docs, Excel sheets, etc.
- **Poll**: Create interactive polls with multiple options
- **Location**: Share your current GPS location
- **Wallet**: Payment features (coming soon)

### Liking Messages
- Click the ❤️ button on any message
- See the count of likes on each message

### Supported File Types
- **Images**: JPG, PNG, GIF - displayed inline
- **Videos**: MP4, WebM - playable in chat
- **Documents**: PDF, DOC, TXT, etc. - downloadable

## Technical Details

### Stack
- **Backend**: Node.js, Express
- **Real-time**: Socket.io
- **File Upload**: Multer
- **Frontend**: Vanilla JavaScript, HTML5, CSS3

### File Structure
```
chat-app/
├── server.js           # Express server and Socket.io logic
├── package.json        # Dependencies
├── public/
│   ├── login.html      # Login page
│   ├── chat.html       # Main chat interface
│   ├── chat.js         # Client-side JavaScript
│   └── style.css       # Telegram-inspired styling
└── uploads/            # Uploaded files storage
```

### Port Configuration
Default port is **3000**. To change it, set the PORT environment variable:
```bash
PORT=8080 npm start
```

## Multiple Users

To test with multiple users:
1. Open multiple browser windows (or use incognito/private mode)
2. Login with different access codes in each window
3. All messages and files are shared in real-time across all sessions

## Message Persistence

- **All messages and files are stored in memory** and persist across sessions
- When a user joins, they see the complete chat history
- Messages remain until manually cleared by an admin
- Uploaded files are stored in the `uploads/` directory

## Admin Dashboard

Access the comprehensive admin dashboard at: `http://localhost:3000/dashboard.html`

**Admin Key**: `Admin1234`

### Dashboard Features:
- **Overview**: Real-time statistics (groups, users, messages, online count)
- **Groups**: Create and manage chat groups, assign users to groups
- **Users**: Manage user accounts and permissions
- **Messages**: View and moderate all chat messages
- **Settings**: Configure system settings
- **Clear History**: Permanently delete all messages (with confirmation)

### Simple Admin Panel
Also available: `http://localhost:3000/admin.html` - Quick access to clear history only

**Admin Key**: `Admin1234`

## Progressive Web App (PWA)

PushVault Dev can be installed as a native app on any device!

### Installation:

**On Desktop (Chrome/Edge):**
1. Open the app in browser
2. Look for install icon in address bar
3. Click "Install" or use the in-app prompt
4. App appears as desktop application

**On Mobile (Android/iOS):**
1. Open app in browser (Chrome/Safari)
2. Tap "Add to Home Screen" prompt
3. Or tap browser menu → "Add to Home Screen"
4. App appears on home screen like native app

**Benefits:**
- Works offline (cached content)
- Faster loading times
- Full-screen experience
- Native app feel
- Push notifications (future)

## Mobile Features

- **Responsive Design**: Optimized for all screen sizes
- **Mobile Header**: Logo, menu, and logout button always visible
- **Sidebar Menu**: Swipe or tap menu to access user list
- **Touch Optimized**: Large tap targets for easy interaction
- **Mobile Logout**: Always accessible logout button in header

## Notes

- Maximum file size: 50MB
- The application works on local network - others can access via your local IP
- Messages are stored in memory - they will be lost if the server restarts

## Troubleshooting

**Server won't start:**
- Make sure port 3000 is not in use
- Run `npm install` to ensure dependencies are installed

**Can't upload files:**
- Check that the `uploads/` directory exists
- Verify file size is under 50MB

**Not receiving messages:**
- Check browser console for errors
- Ensure JavaScript is enabled
- Try refreshing the page

## Future Enhancements

Possible additions:
- Voice/video calling integration
- Message persistence (database)
- User avatars
- Message search
- Emoji picker
- Read receipts
- Private messaging

---

**Enjoy chatting! 🚀**
