// Check authentication
const accessCode = sessionStorage.getItem('accessCode');
if (!accessCode) {
    window.location.href = '/';
}

// Initialize Socket.io
const socket = io();

// DOM Elements
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const messagesContainer = document.getElementById('messagesContainer');
const fileInput = document.getElementById('fileInput');
const attachBtn = document.getElementById('attachBtn');
const userList = document.getElementById('userList');
const onlineCount = document.getElementById('onlineCount');
const currentUser = document.getElementById('currentUser');
const logoutBtn = document.getElementById('logoutBtn');
const typingIndicator = document.getElementById('typingIndicator');

// Store messages with their like data
const messages = new Map();

// Generate consistent color for each user
const userColors = new Map();
const usedHues = new Set();

function getUserColor(username) {
    if (!userColors.has(username)) {
        // Generate a color based on username hash
        let hash = 0;
        for (let i = 0; i < username.length; i++) {
            hash = username.charCodeAt(i) + ((hash << 5) - hash);
        }
        
        // Generate more distinct hues by spacing them out
        let hue = Math.abs(hash % 360);
        
        // Try to find a hue that's at least 30 degrees away from existing ones
        let attempts = 0;
        while (attempts < 12) {
            let tooClose = false;
            for (let usedHue of usedHues) {
                const diff = Math.abs(hue - usedHue);
                if (diff < 30 || diff > 330) { // Account for circular hue
                    tooClose = true;
                    break;
                }
            }
            if (!tooClose || usedHues.size === 0) break;
            hue = (hue + 30) % 360;
            attempts++;
        }
        
        usedHues.add(hue);
        
        // Generate vibrant colors with good contrast
        const saturation = 75 + (Math.abs(hash) % 15); // 75-90%
        const lightness = 48 + (Math.abs(hash >> 8) % 12); // 48-60%
        
        userColors.set(username, `hsl(${hue}, ${saturation}%, ${lightness}%)`);
    }
    return userColors.get(username);
}

// Notification sound
const audioContext = new (window.AudioContext || window.webkitAudioContext)();

function playNotificationSound() {
    try {
        // Create oscillators for a pleasant notification sound
        const now = audioContext.currentTime;
        
        // First tone
        const oscillator1 = audioContext.createOscillator();
        const gainNode1 = audioContext.createGain();
        oscillator1.connect(gainNode1);
        gainNode1.connect(audioContext.destination);
        oscillator1.frequency.value = 800;
        gainNode1.gain.setValueAtTime(0.3, now);
        gainNode1.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
        oscillator1.start(now);
        oscillator1.stop(now + 0.1);
        
        // Second tone (slightly higher)
        const oscillator2 = audioContext.createOscillator();
        const gainNode2 = audioContext.createGain();
        oscillator2.connect(gainNode2);
        gainNode2.connect(audioContext.destination);
        oscillator2.frequency.value = 1000;
        gainNode2.gain.setValueAtTime(0, now + 0.08);
        gainNode2.gain.setValueAtTime(0.3, now + 0.08);
        gainNode2.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
        oscillator2.start(now + 0.08);
        oscillator2.stop(now + 0.25);
    } catch (error) {
        console.log('Audio notification not supported');
    }
}

// Set current user display (will be set by server)
let currentUsername = `User-${accessCode}`;
currentUser.textContent = currentUsername;

// Join the chat
socket.emit('join', accessCode);

// Update username when joined
socket.on('username-set', (username) => {
    currentUsername = username;
    currentUser.textContent = username;
});

// Load message history
socket.on('message-history', (history) => {
    // Clear welcome message if exists
    const welcomeMsg = messagesContainer.querySelector('.welcome-message');
    if (welcomeMsg) {
        welcomeMsg.remove();
    }
    
    // Load all historical messages
    history.forEach(message => {
        if (message.type === 'text') {
            addMessage(message, true);
        } else if (message.type === 'file') {
            addFileMessage(message, true);
        } else if (message.type === 'poll') {
            addPollMessage(message, true);
        } else if (message.type === 'location') {
            addLocationMessage(message, true);
        }
    });
});

// Clear history event
socket.on('history-cleared', () => {
    // Remove all messages except system messages
    const messages = messagesContainer.querySelectorAll('.message, .file-message');
    messages.forEach(msg => msg.remove());
    addSystemMessage('Chat history has been cleared by admin');
});

// Typing indicator
let typingTimer;
messageInput.addEventListener('input', () => {
    socket.emit('typing');
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        socket.emit('stop-typing');
    }, 1000);
});

// Send message
function sendMessage() {
    const text = messageInput.value.trim();
    if (text) {
        socket.emit('chat-message', { text });
        messageInput.value = '';
        socket.emit('stop-typing');
    }
}

sendBtn.addEventListener('click', sendMessage);
messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// Attachment menu
const attachmentMenu = document.getElementById('attachmentMenu');
const photoInput = document.getElementById('photoInput');
const documentInput = document.getElementById('documentInput');
const photoBtn = document.getElementById('photoBtn');
const documentBtn = document.getElementById('documentBtn');
const pollBtn = document.getElementById('pollBtn');
const locationBtn = document.getElementById('locationBtn');
const walletBtn = document.getElementById('walletBtn');

// Toggle attachment menu
attachBtn.addEventListener('click', () => {
    attachmentMenu.classList.toggle('show');
});

// Close menu when clicking outside
document.addEventListener('click', (e) => {
    if (!attachBtn.contains(e.target) && !attachmentMenu.contains(e.target)) {
        attachmentMenu.classList.remove('show');
    }
});

// Photo or Video
photoBtn.addEventListener('click', () => {
    photoInput.click();
    attachmentMenu.classList.remove('show');
});

// Document
documentBtn.addEventListener('click', () => {
    documentInput.click();
    attachmentMenu.classList.remove('show');
});

// Poll
pollBtn.addEventListener('click', () => {
    attachmentMenu.classList.remove('show');
    createPoll();
});

// Location
locationBtn.addEventListener('click', () => {
    attachmentMenu.classList.remove('show');
    shareLocation();
});

// Wallet
walletBtn.addEventListener('click', () => {
    attachmentMenu.classList.remove('show');
    alert('Wallet feature - Coming soon!');
});

// Handle file uploads
async function handleFileUpload(files, inputElement) {
    for (const file of files) {
        const formData = new FormData();
        formData.append('file', file);
        
        try {
            addSystemMessage(`Uploading ${file.name}...`);
            
            const response = await fetch('/upload', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                socket.emit('file-message', { file: result });
            } else {
                addSystemMessage(`Failed to upload ${file.name}`);
            }
        } catch (error) {
            addSystemMessage(`Error uploading ${file.name}`);
        }
    }
    inputElement.value = '';
}

fileInput.addEventListener('change', (e) => {
    handleFileUpload(Array.from(e.target.files), fileInput);
});

photoInput.addEventListener('change', (e) => {
    handleFileUpload(Array.from(e.target.files), photoInput);
});

documentInput.addEventListener('change', (e) => {
    handleFileUpload(Array.from(e.target.files), documentInput);
});

// Create poll
function createPoll() {
    const question = prompt('Enter poll question:');
    if (!question) return;
    
    const options = [];
    for (let i = 1; i <= 4; i++) {
        const option = prompt(`Option ${i} (leave empty to finish):`);
        if (!option) break;
        options.push(option);
    }
    
    if (options.length < 2) {
        alert('A poll needs at least 2 options');
        return;
    }
    
    socket.emit('poll-message', { question, options });
}

// Share location
function shareLocation() {
    if (!navigator.geolocation) {
        alert('Geolocation is not supported by your browser');
        return;
    }
    
    addSystemMessage('Getting your location...');
    navigator.geolocation.getCurrentPosition(
        (position) => {
            socket.emit('location-message', {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            });
        },
        (error) => {
            addSystemMessage('Unable to get location');
        }
    );
}

// Receive messages
socket.on('chat-message', (message) => {
    messages.set(message.id, message);
    addMessage(message);
    
    // Play notification sound if not own message
    if (message.username !== currentUsername) {
        playNotificationSound();
    }
});

socket.on('file-message', (message) => {
    messages.set(message.id, message);
    addFileMessage(message);
    
    // Play notification sound if not own message
    if (message.username !== currentUsername) {
        playNotificationSound();
    }
});

socket.on('poll-message', (message) => {
    messages.set(message.id, message);
    addPollMessage(message);
    
    // Play notification sound if not own message
    if (message.username !== currentUsername) {
        playNotificationSound();
    }
});

socket.on('poll-updated', ({ messageId, poll }) => {
    const message = messages.get(messageId);
    if (message) {
        message.poll = poll;
        updatePollDisplay(messageId, poll);
    }
});

socket.on('location-message', (message) => {
    messages.set(message.id, message);
    addLocationMessage(message);
    
    // Play notification sound if not own message
    if (message.username !== currentUsername) {
        playNotificationSound();
    }
});

// User events
socket.on('user-joined', (username) => {
    addSystemMessage(`${username} joined the chat`);
    playNotificationSound();
});

socket.on('user-left', (username) => {
    addSystemMessage(`${username} left the chat`);
});

socket.on('user-list', (users) => {
    updateUserList(users);
});

socket.on('user-typing', (username) => {
    typingIndicator.textContent = `${username} is typing...`;
    typingIndicator.style.display = 'block';
});

socket.on('user-stop-typing', () => {
    typingIndicator.style.display = 'none';
});

socket.on('message-liked', ({ messageId, username }) => {
    const message = messages.get(messageId);
    if (message) {
        if (!message.likes.includes(username)) {
            message.likes.push(username);
            updateMessageLikes(messageId, message.likes);
        }
    }
});

// Listen for reaction updates from server
socket.on('reaction-updated', ({ messageId, username, emoji, reactions }) => {
    console.log('Received reaction-updated:', { messageId, username, emoji, reactions });
    console.log('Current username:', currentUsername);
    
    const message = messages.get(messageId);
    if (message) {
        // Update message reactions
        message.reactions = reactions;
        console.log('Updated message.reactions:', message.reactions);
        
        // Update the reactions display
        updateReactionsDisplay(messageId, reactions);
    } else {
        console.error('Message not found in messages Map:', messageId);
        console.log('Available messages:', Array.from(messages.keys()));
    }
});

// Add text message to UI
function addMessage(message, isHistory = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    messageDiv.dataset.messageId = message.id;
    
    const isOwnMessage = message.username === currentUsername;
    if (isOwnMessage) {
        messageDiv.classList.add('own-message');
    }
    
    const userColor = isOwnMessage ? '#7bc47f' : getUserColor(message.username);
    const bubbleGradient = isOwnMessage 
        ? 'linear-gradient(145deg, #1a4428, #265a33)'
        : `linear-gradient(145deg, ${adjustColorBrightness(userColor, -20)}, ${adjustColorBrightness(userColor, -10)})`;
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <span class="message-username" style="color: ${userColor};">${message.username}</span>
            <span class="message-time">${formatTime(message.timestamp)}</span>
        </div>
        <div class="message-content" style="background: ${bubbleGradient};">
            <div class="message-text">${escapeHtml(message.text)}</div>
        </div>
        <div class="message-footer"></div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    updateReactionsDisplay(message.id, message.reactions || {});
    
    if (!isHistory) {
        scrollToBottom();
    }
}
// Add file message to UI
function addFileMessage(message, isHistory = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message file-message';
    messageDiv.dataset.messageId = message.id;
    
    const isOwnMessage = message.username === currentUsername;
    if (isOwnMessage) {
        messageDiv.classList.add('own-message');
    }
    
    const userColor = isOwnMessage ? '#7bc47f' : getUserColor(message.username);
    const bubbleGradient = isOwnMessage 
        ? 'linear-gradient(145deg, #1a4428, #265a33)'
        : `linear-gradient(145deg, ${adjustColorBrightness(userColor, -20)}, ${adjustColorBrightness(userColor, -10)})`;
    
    const file = message.file;
    const isImage = file.mimetype.startsWith('image/');
    const isVideo = file.mimetype.startsWith('video/');
    
    let filePreview = '';
    if (isImage) {
        filePreview = `<img src="${file.path}" alt="${file.originalname}" class="file-preview-image">`;
    } else if (isVideo) {
        filePreview = `<video src="${file.path}" controls class="file-preview-video"></video>`;
    } else {
        filePreview = `
            <div class="file-icon">📄</div>
            <div class="file-info">
                <div class="file-name">${file.originalname}</div>
                <div class="file-size">${formatFileSize(file.size)}</div>
            </div>
        `;
    }
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <span class="message-username" style="color: ${userColor};">${message.username}</span>
            <span class="message-time">${formatTime(message.timestamp)}</span>
        </div>
        <div class="message-content" style="background: ${bubbleGradient};">
            <a href="${file.path}" download="${file.originalname}" class="file-preview">
                ${filePreview}
            </a>
        </div>
        <div class="message-footer"></div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    updateReactionsDisplay(message.id, message.reactions || {});
    
    if (!isHistory) {
        scrollToBottom();
    } else {
        setTimeout(() => scrollToBottom(), 100);
    }
}

// Add system message
function addSystemMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'system-message';
    messageDiv.textContent = text;
    messagesContainer.appendChild(messageDiv);
    scrollToBottom();
}

// Store user reactions for each message
const userReactions = new Map();
const lastUsedEmoji = new Map(); // Store last used emoji per message

// Toggle emoji picker
function toggleEmojiPicker(event, messageId) {
    event.stopPropagation();
    
    // Close all other pickers
    document.querySelectorAll('.emoji-picker').forEach(picker => {
        if (picker.id !== `picker-${messageId}`) {
            picker.classList.remove('show');
        }
    });
    
    // Toggle current picker
    const picker = document.getElementById(`picker-${messageId}`);
    if (picker) {
        picker.classList.toggle('show');
    }
}

// React to message with emoji
function reactToMessage(messageId, emoji) {
    console.log('reactToMessage called:', messageId, emoji);
    userReactions.set(messageId, emoji);
    lastUsedEmoji.set(messageId, emoji); // Store the last used emoji
    
    const message = messages.get(messageId);
    if (message) {
        // Initialize reactions object if it doesn't exist
        if (!message.reactions) {
            message.reactions = {};
        }
        message.reactions[currentUsername] = emoji;
        
        // Update display locally for instant feedback
        updateReactionsDisplay(messageId, message.reactions);
    } else {
        console.error('Message not found:', messageId);
    }
    
    // Close the picker
    const picker = document.getElementById(`picker-${messageId}`);
    if (picker) {
        picker.classList.remove('show');
    }
    
    // Send reaction to server to broadcast to all users
    socket.emit('emoji-reaction', { messageId, emoji });
}

// Update reactions display with counts
function updateReactionsDisplay(messageId, reactions) {
    const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
    if (!messageDiv) {
        console.log('Message div not found for', messageId);
        return;
    }
    
    const footer = messageDiv.querySelector('.message-footer');
    if (!footer) {
        console.log('Footer not found for', messageId);
        return;
    }
    
    // Count reactions by emoji
    const reactionCounts = {};
    const usersByEmoji = {};
    
    Object.entries(reactions || {}).forEach(([user, emoji]) => {
        if (!reactionCounts[emoji]) {
            reactionCounts[emoji] = 0;
            usersByEmoji[emoji] = [];
        }
        reactionCounts[emoji]++;
        usersByEmoji[emoji].push(user);
    });
    
    // Build reactions HTML
    let reactionsHTML = '<div class="all-reactions">';
    
    Object.entries(reactionCounts).forEach(([emoji, count]) => {
        const userReacted = usersByEmoji[emoji].includes(currentUsername);
        const userReactedClass = userReacted ? 'user-reacted' : '';
        reactionsHTML += `
            <div class="reaction-item ${userReactedClass}" onclick="reactToMessage('${messageId}', '${emoji}')">
                <span class="emoji-icon">${emoji}</span>
                <span class="reaction-count">${count}</span>
            </div>
        `;
    });
    
    reactionsHTML += '</div>';
    
    // Add the add reaction button
    // Check if user already reacted, use that emoji, otherwise check last used, otherwise use +
    const userReaction = reactions[currentUsername];
    const displayEmoji = userReaction || lastUsedEmoji.get(messageId) || '+';
    
    reactionsHTML += `
        <div class="reaction-badge">
            <button class="add-reaction-btn" onclick="toggleEmojiPicker(event, '${messageId}')">
                <span class="emoji-icon">${displayEmoji}</span>
            </button>
            <div class="emoji-picker" id="picker-${messageId}">
                <button class="emoji-option" onclick="reactToMessage('${messageId}', '❤️')">❤️</button>
                <button class="emoji-option" onclick="reactToMessage('${messageId}', '👍')">👍</button>
                <button class="emoji-option" onclick="reactToMessage('${messageId}', '😂')">😂</button>
                <button class="emoji-option" onclick="reactToMessage('${messageId}', '😮')">😮</button>
                <button class="emoji-option" onclick="reactToMessage('${messageId}', '😢')">😢</button>
                <button class="emoji-option" onclick="reactToMessage('${messageId}', '🔥')">🔥</button>
            </div>
        </div>
    `;
    
    footer.innerHTML = reactionsHTML;
    console.log('Updated reactions for', messageId, 'Display emoji:', displayEmoji);
}

// Like message (kept for backward compatibility)
function likeMessage(messageId) {
    socket.emit('like-message', messageId);
}

// Close emoji pickers when clicking outside
document.addEventListener('click', (event) => {
    if (!event.target.closest('.add-reaction-btn') && 
        !event.target.closest('.emoji-picker') && 
        !event.target.closest('.reaction-badge')) {
        document.querySelectorAll('.emoji-picker').forEach(picker => {
            picker.classList.remove('show');
        });
    }
});

// Update message likes
function updateMessageLikes(messageId, likes) {
    const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
    if (messageDiv) {
        const likeCount = messageDiv.querySelector('.like-count');
        if (likeCount) {
            likeCount.textContent = likes.length || '';
        }
    }
}

// Update user list
function updateUserList(users) {
    userList.innerHTML = '';
    users.forEach(username => {
        const userDiv = document.createElement('div');
        userDiv.className = 'user-item';
        userDiv.innerHTML = `
            <span class="user-status-dot"></span>
            <span class="user-name">${username}</span>
        `;
        userList.appendChild(userDiv);
    });
    
    onlineCount.textContent = `${users.length} member${users.length !== 1 ? 's' : ''} online`;
}

// Logout
logoutBtn.addEventListener('click', () => {
    sessionStorage.removeItem('accessCode');
    window.location.href = '/';
});

// Mobile menu and logout
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const mobileLogoutBtn = document.getElementById('mobileLogoutBtn');
const sidebar = document.querySelector('.sidebar');

if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', () => {
        sidebar.classList.toggle('open');
    });
    
    // Close sidebar when clicking outside
    document.addEventListener('click', (e) => {
        if (!sidebar.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
            sidebar.classList.remove('open');
        }
    });
}

if (mobileLogoutBtn) {
    mobileLogoutBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to logout?')) {
            sessionStorage.removeItem('accessCode');
            window.location.href = '/';
        }
    });
}

// PWA Install Prompt
let deferredPrompt;
const installPrompt = document.createElement('div');
installPrompt.className = 'pwa-install-prompt';
installPrompt.innerHTML = `
    <div class="pwa-prompt-content">
        <img src="logo.png" alt="Logo" class="pwa-prompt-logo">
        <div class="pwa-prompt-text">
            <strong>Install PushVault Dev</strong>
            <p>Install our app for a better experience</p>
        </div>
        <button class="pwa-install-btn" id="pwaInstallBtn">Install</button>
        <button class="pwa-dismiss-btn" id="pwaDismissBtn">×</button>
    </div>
`;

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    
    // Don't show if already dismissed
    if (!localStorage.getItem('pwa-dismissed')) {
        document.body.appendChild(installPrompt);
        setTimeout(() => installPrompt.classList.add('show'), 500);
    }
});

document.addEventListener('click', (e) => {
    if (e.target.id === 'pwaInstallBtn') {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then((choiceResult) => {
                deferredPrompt = null;
                installPrompt.remove();
            });
        }
    }
    
    if (e.target.id === 'pwaDismissBtn') {
        installPrompt.classList.remove('show');
        setTimeout(() => installPrompt.remove(), 300);
        localStorage.setItem('pwa-dismissed', 'true');
    }
});

// Register service worker
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => console.log('SW registered:', registration))
            .catch(err => console.log('SW registration failed:', err));
    });
}

// Utility functions
function formatTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Add poll message to UI
function addPollMessage(message, isHistory = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message poll-message';
    messageDiv.dataset.messageId = message.id;
    
    const isOwnMessage = message.username === currentUsername;
    if (isOwnMessage) {
        messageDiv.classList.add('own-message');
    }
    
    const userColor = isOwnMessage ? '#7bc47f' : getUserColor(message.username);
    const bubbleGradient = isOwnMessage 
        ? 'linear-gradient(145deg, #1a4428, #265a33)'
        : `linear-gradient(145deg, ${adjustColorBrightness(userColor, -20)}, ${adjustColorBrightness(userColor, -10)})`;
    
    const totalVotes = message.poll.options.reduce((sum, opt) => sum + opt.count, 0);
    
    const optionsHtml = message.poll.options.map((option, index) => {
        const percentage = totalVotes > 0 ? Math.round((option.count / totalVotes) * 100) : 0;
        const hasVoted = option.votes.includes(currentUsername);
        
        return `
            <div class="poll-option" data-option-index="${index}" onclick="votePoll('${message.id}', ${index})">
                <div class="poll-option-bar" style="width: ${percentage}%"></div>
                <div class="poll-option-content">
                    <span class="poll-option-text">${escapeHtml(option.text)} ${hasVoted ? '✓' : ''}</span>
                    <span class="poll-option-count">${option.count} (${percentage}%)</span>
                </div>
            </div>
        `;
    }).join('');
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <span class="message-username" style="color: ${userColor};">${message.username}</span>
            <span class="message-time">${formatTime(message.timestamp)}</span>
        </div>
        <div class="message-content" style="background: ${bubbleGradient};">
            <div class="poll-container">
                <div class="poll-question">📊 ${escapeHtml(message.poll.question)}</div>
                <div class="poll-options">
                    ${optionsHtml}
                </div>
                <div class="poll-footer">${totalVotes} vote${totalVotes !== 1 ? 's' : ''}</div>
            </div>
        </div>
        <div class="message-footer"></div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    updateReactionsDisplay(message.id, message.reactions || {});
    
    if (!isHistory) {
        scrollToBottom();
    }
}

// Vote on poll
function votePoll(messageId, optionIndex) {
    socket.emit('poll-vote', { messageId, optionIndex });
}

// Update poll display
function updatePollDisplay(messageId, poll) {
    const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
    if (!messageDiv) return;
    
    const totalVotes = poll.options.reduce((sum, opt) => sum + opt.count, 0);
    const pollOptions = messageDiv.querySelector('.poll-options');
    
    pollOptions.innerHTML = poll.options.map((option, index) => {
        const percentage = totalVotes > 0 ? Math.round((option.count / totalVotes) * 100) : 0;
        const hasVoted = option.votes.includes(currentUsername);
        
        return `
            <div class="poll-option" data-option-index="${index}" onclick="votePoll('${messageId}', ${index})">
                <div class="poll-option-bar" style="width: ${percentage}%"></div>
                <div class="poll-option-content">
                    <span class="poll-option-text">${escapeHtml(option.text)} ${hasVoted ? '✓' : ''}</span>
                    <span class="poll-option-count">${option.count} (${percentage}%)</span>
                </div>
            </div>
        `;
    }).join('');
    
    const pollFooter = messageDiv.querySelector('.poll-footer');
    if (pollFooter) {
        pollFooter.textContent = `${totalVotes} vote${totalVotes !== 1 ? 's' : ''}`;
    }
}

// Add location message to UI
function addLocationMessage(message, isHistory = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message location-message';
    messageDiv.dataset.messageId = message.id;
    
    const isOwnMessage = message.username === currentUsername;
    if (isOwnMessage) {
        messageDiv.classList.add('own-message');
    }
    
    const userColor = isOwnMessage ? '#7bc47f' : getUserColor(message.username);
    const bubbleGradient = isOwnMessage 
        ? 'linear-gradient(145deg, #1a4428, #265a33)'
        : `linear-gradient(145deg, ${adjustColorBrightness(userColor, -20)}, ${adjustColorBrightness(userColor, -10)})`;
    
    const { latitude, longitude } = message.location;
    const mapUrl = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=15/${latitude}/${longitude}`;
    const googleMapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <span class="message-username" style="color: ${userColor};">${message.username}</span>
            <span class="message-time">${formatTime(message.timestamp)}</span>
        </div>
        <div class="message-content" style="background: ${bubbleGradient};">
            <div class="location-container">
                <div class="location-icon">📍</div>
                <div class="location-info">
                    <div class="location-title">Shared Location</div>
                    <div class="location-coords">${latitude.toFixed(6)}, ${latitude.toFixed(6)}</div>
                    <div class="location-links">
                        <a href="${googleMapsUrl}" target="_blank" class="location-link">Google Maps</a>
                        <a href="${mapUrl}" target="_blank" class="location-link">OpenStreetMap</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="message-footer"></div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    updateReactionsDisplay(message.id, message.reactions || {});
    
    if (!isHistory) {
        scrollToBottom();
    }
}

// Adjust color brightness for gradient effect
function adjustColorBrightness(hslColor, percent) {
    const match = hslColor.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/);
    if (!match) return hslColor;
    
    const h = match[1];
    const s = match[2];
    let l = parseInt(match[3]);
    
    l = Math.max(20, Math.min(80, l + percent));
    
    return `hsl(${h}, ${s}%, ${l}%)`;
}

function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}
