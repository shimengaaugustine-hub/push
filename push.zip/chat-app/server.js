const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// User name mapping
const USER_FILE = path.join(__dirname, 'data', 'users.json');
let validUsers = {
  'CHAT001': 'Timo',
  'CHAT002': 'Augustine',
  'CHAT003': 'Jordan',
  'CHAT004': 'Bug',
  'CHAT005': 'Brian'
};

// Load users from file
function loadUsers() {
  try {
    if (fs.existsSync(USER_FILE)) {
      const data = fs.readFileSync(USER_FILE, 'utf8');
      validUsers = JSON.parse(data);
      console.log(`Loaded ${Object.keys(validUsers).length} users from storage`);
    } else {
      console.log('No existing users file, using default users');
      saveUsers();
    }
  } catch (error) {
    console.error('Error loading users:', error);
  }
}

// Save users to file
function saveUsers() {
  try {
    fs.writeFileSync(USER_FILE, JSON.stringify(validUsers, null, 2), 'utf8');
  } catch (error) {
    console.error('Error saving users:', error);
  }
}

// Get valid codes array
function getValidCodes() {
  return Object.keys(validUsers);
}

// Store connected users
const users = new Map();

// Store all messages and files (persisted to disk)
const MESSAGE_FILE = path.join(__dirname, 'data', 'messages.json');
let messageHistory = [];

// Ensure data directory exists
if (!fs.existsSync(path.join(__dirname, 'data'))) {
  fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}

// Load message history from file on startup
function loadMessages() {
  try {
    if (fs.existsSync(MESSAGE_FILE)) {
      const data = fs.readFileSync(MESSAGE_FILE, 'utf8');
      messageHistory = JSON.parse(data);
      console.log(`Loaded ${messageHistory.length} messages from storage`);
    } else {
      console.log('No existing message history found, starting fresh');
    }
  } catch (error) {
    console.error('Error loading messages:', error);
    messageHistory = [];
  }
}

// Save message history to file
function saveMessages() {
  try {
    fs.writeFileSync(MESSAGE_FILE, JSON.stringify(messageHistory, null, 2), 'utf8');
  } catch (error) {
    console.error('Error saving messages:', error);
  }
}

// Load messages and users on startup
loadMessages();
loadUsers();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

// Serve static files
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));
app.use(express.json());

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/verify-code', (req, res) => {
  const { code } = req.body;
  if (getValidCodes().includes(code)) {
    res.json({ valid: true });
  } else {
    res.json({ valid: false });
  }
});

app.post('/upload', upload.single('file'), (req, res) => {
  if (req.file) {
    res.json({
      success: true,
      filename: req.file.filename,
      originalname: req.file.originalname,
      size: req.file.size,
      mimetype: req.file.mimetype,
      path: '/uploads/' + req.file.filename
    });
  } else {
    res.status(400).json({ success: false, message: 'No file uploaded' });
  }
});

// Admin endpoint to create new user
app.post('/create-user', (req, res) => {
  const { adminKey, username } = req.body;
  
  if (adminKey !== 'Admin1234') {
    return res.status(403).json({ success: false, message: 'Invalid admin key' });
  }
  
  if (!username || username.trim().length === 0) {
    return res.status(400).json({ success: false, message: 'Username is required' });
  }
  
  // Generate new code
  let newCode;
  let codeNum = Object.keys(validUsers).length + 1;
  
  do {
    newCode = `CHAT${String(codeNum).padStart(3, '0')}`;
    codeNum++;
  } while (validUsers[newCode]);
  
  // Add user
  validUsers[newCode] = username.trim();
  saveUsers();
  
  console.log(`New user created: ${username} (${newCode})`);
  res.json({ 
    success: true, 
    code: newCode, 
    username: username.trim(),
    message: `User ${username} created with code ${newCode}` 
  });
});

// Admin endpoint to get all users
app.post('/get-users', (req, res) => {
  const { adminKey } = req.body;
  
  if (adminKey !== 'Admin1234') {
    return res.status(403).json({ success: false, message: 'Invalid admin key' });
  }
  
  const users = Object.entries(validUsers).map(([code, username]) => ({
    code,
    username
  }));
  
  res.json({ success: true, users });
});

// Admin endpoint to delete user
app.post('/delete-user', (req, res) => {
  const { adminKey, code } = req.body;
  
  if (adminKey !== 'Admin1234') {
    return res.status(403).json({ success: false, message: 'Invalid admin key' });
  }
  
  if (!code) {
    return res.status(400).json({ success: false, message: 'User code is required' });
  }
  
  if (!validUsers[code]) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }
  
  const username = validUsers[code];
  delete validUsers[code];
  saveUsers();
  
  console.log(`User deleted: ${username} (${code})`);
  res.json({ 
    success: true, 
    message: `User ${username} deleted successfully` 
  });
});

// Admin endpoint to clear message history
app.post('/clear-history', (req, res) => {
  const { adminKey } = req.body;
  // Simple admin key check (you can change this to a more secure method)
  if (adminKey === 'Admin1234') {
    const count = messageHistory.length;
    messageHistory.length = 0; // Clear array
    saveMessages(); // Save empty history
    console.log(`Message history cleared (${count} messages removed)`);
    // Notify all connected clients to clear their UI
    io.emit('history-cleared');
    res.json({ success: true, message: `Cleared ${count} messages` });
  } else {
    res.status(403).json({ success: false, message: 'Invalid admin key' });
  }
});

// Stats API for dashboard
app.get('/api/stats', (req, res) => {
  res.json({
    messages: messageHistory.length,
    online: users.size,
    users: Object.keys(validUsers).length,
    groups: 1
  });
});

// Socket.io connection handling
io.on('connection', (socket) => {
  console.log('New client connected');

  socket.on('join', (code) => {
    if (getValidCodes().includes(code)) {
      const username = validUsers[code] || `User-${code}`;
      users.set(socket.id, { username, code });
      socket.username = username;
      socket.code = code;

      // Send username to the user
      socket.emit('username-set', username);

      // Send message history to the newly joined user
      socket.emit('message-history', messageHistory);

      // Send user list to all clients
      io.emit('user-list', Array.from(users.values()).map(u => u.username));

      // Notify others about new user
      socket.broadcast.emit('user-joined', username);

      console.log(`${username} joined the chat`);
    }
  });

  socket.on('chat-message', (data) => {
    const user = users.get(socket.id);
    if (user) {
      const message = {
        id: Date.now() + '-' + socket.id,
        type: 'text',
        username: user.username,
        text: data.text,
        timestamp: new Date().toISOString(),
        likes: [],
        reactions: {} // Store reactions as {username: emoji}
      };
      messageHistory.push(message);
      saveMessages();
      io.emit('chat-message', message);
    }
  });

  socket.on('file-message', (data) => {
    const user = users.get(socket.id);
    if (user) {
      const message = {
        id: Date.now() + '-' + socket.id,
        type: 'file',
        username: user.username,
        file: data.file,
        timestamp: new Date().toISOString(),
        likes: [],
        reactions: {} // Store reactions as {username: emoji}
      };
      messageHistory.push(message);
      saveMessages();
      io.emit('file-message', message);
    }
  });

  socket.on('like-message', (messageId) => {
    const user = users.get(socket.id);
    if (user) {
      // Find message in history and add like
      const message = messageHistory.find(m => m.id === messageId);
      if (message && !message.likes.includes(user.username)) {
        message.likes.push(user.username);
        saveMessages();
      }
      
      io.emit('message-liked', {
        messageId,
        username: user.username
      });
    }
  });

  // Handle emoji reactions
  socket.on('emoji-reaction', (data) => {
    const user = users.get(socket.id);
    if (user) {
      const message = messageHistory.find(m => m.id === data.messageId);
      if (message) {
        // Initialize reactions object if it doesn't exist
        if (!message.reactions) {
          message.reactions = {};
        }
        
        // Store the user's reaction
        message.reactions[user.username] = data.emoji;
        saveMessages();
        
        // Broadcast the reaction to all users
        io.emit('reaction-updated', {
          messageId: data.messageId,
          username: user.username,
          emoji: data.emoji,
          reactions: message.reactions
        });
      }
    }
  });

  socket.on('poll-message', (data) => {
    const user = users.get(socket.id);
    if (user) {
      const message = {
        id: Date.now() + '-' + socket.id,
        type: 'poll',
        username: user.username,
        poll: {
          question: data.question,
          options: data.options.map(opt => ({
            text: opt,
            votes: [],
            count: 0
          }))
        },
        timestamp: new Date().toISOString(),
        likes: [],
        reactions: {} // Store reactions as {username: emoji}
      };
      messageHistory.push(message);
      saveMessages();
      io.emit('poll-message', message);
    }
  });

  socket.on('poll-vote', (data) => {
    const user = users.get(socket.id);
    if (user) {
      const message = messageHistory.find(m => m.id === data.messageId);
      if (message && message.type === 'poll') {
        // Remove previous vote if exists
        message.poll.options.forEach(opt => {
          const index = opt.votes.indexOf(user.username);
          if (index > -1) {
            opt.votes.splice(index, 1);
            opt.count = opt.votes.length;
          }
        });
        
        // Add new vote
        const option = message.poll.options[data.optionIndex];
        if (option && !option.votes.includes(user.username)) {
          option.votes.push(user.username);
          option.count = option.votes.length;
          saveMessages();
        }
        
        io.emit('poll-updated', {
          messageId: data.messageId,
          poll: message.poll
        });
      }
    }
  });

  socket.on('location-message', (data) => {
    const user = users.get(socket.id);
    if (user) {
      const message = {
        id: Date.now() + '-' + socket.id,
        type: 'location',
        username: user.username,
        location: {
          latitude: data.latitude,
          longitude: data.longitude
        },
        timestamp: new Date().toISOString(),
        likes: [],
        reactions: {} // Store reactions as {username: emoji}
      };
      messageHistory.push(message);
      saveMessages();
      io.emit('location-message', message);
    }
  });

  socket.on('typing', () => {
    const user = users.get(socket.id);
    if (user) {
      socket.broadcast.emit('user-typing', user.username);
    }
  });

  socket.on('stop-typing', () => {
    socket.broadcast.emit('user-stop-typing');
  });

  socket.on('disconnect', () => {
    const user = users.get(socket.id);
    if (user) {
      users.delete(socket.id);
      io.emit('user-list', Array.from(users.values()).map(u => u.username));
      io.emit('user-left', user.username);
      console.log(`${user.username} disconnected`);
    }
  });
});

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

server.listen(PORT, HOST, () => {
  console.log(`Server running on ${HOST}:${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`Access the chat at http://localhost:${PORT}`);
  console.log('\nValid login codes:');
  Object.entries(validUsers).forEach(([code, name]) => 
    console.log(`  - ${code} (${name})`)
  );
});
